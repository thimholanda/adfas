<?php

$copy_text_1 = str_replace(
	array(
		'%%year%%',
		'%%date%%',
		'%%title%%',
		'%%sitename%%',
		'%%siteurl%%',
	),
	array(
		date( 'Y' ),
		date( 'Y' ),
		get_bloginfo( 'name' ),
		get_bloginfo( 'name' ),
		get_home_url()
	),
	Better_AMP::get_option( 'footer_copy_1' )
);

$footer_img      = Better_AMP::get_option( 'footer_logo_image' );
$footer_img_size = Better_AMP::get_option( 'footer_logo_image_size' );

?>
<footer class="amp-wp-footer">

	<?php if ( ! empty( $footer_img ) ) { ?>
		<div class="footer-logo">
			<amp-img src="<?php echo esc_url( $footer_img ); ?>"
			         width="<?php echo $footer_img_size['width'] ?>" height="<?php echo $footer_img_size['height'] ?>"
			         alt="<?php echo esc_attr( $this->get( 'blog_name' ) ); ?>"></amp-img>
		</div>

	<?php } ?>
	<div class="footer-copyright">
		<?php

		echo wpautop( $copy_text_1 );

		?>
	</div>
	<?php

	?>
</footer>