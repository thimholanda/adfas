<?php

class BF_Product_Pages_System_Status extends BF_Product_Item {

	public $id = 'system-status';

	public function render_content( $item_data ) {
	}


	public function item_data() {
	}
}