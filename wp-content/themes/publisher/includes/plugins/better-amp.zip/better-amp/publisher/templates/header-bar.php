<?php

$logo = Better_AMP::get_option( 'logo_image' );
$size = Better_AMP::get_option( 'logo_image_size' );
$type = 'custom-logo';

if ( ! $logo ) {

	$logo = $this->get( 'site_icon_url' );

	if ( $logo ) {

		$type = 'site-icon';

		$size = array(
			'width'  => '32px',
			'height' => '32px',
		);

	} else {

		$type = 'none';

		$size = array(
			'width'  => '',
			'height' => '',
		);

	}

}

$logo_text = $this->get( 'blog_name' );

?>
<nav class="amp-wp-title-bar type-<?php echo $type; ?>">
	<div>
		<a href="<?php echo esc_url( $this->get( 'home_url' ) ); ?>">
			<?php if ( $logo ) { ?>
				<amp-img src="<?php echo esc_url( $logo ); ?>"
				         class="<?php echo $type == 'custom-logo' ? 'amp-wp-site-logo' : 'amp-wp-site-icon'; ?>"
				         width="<?php echo $size['width'] ?>" height="<?php echo $size['height'] ?>"
				         alt="<?php echo esc_attr( $logo_text ); ?>"></amp-img>
				<?php

				if ( $type == 'site-icon' ) {
					echo esc_html( $logo_text );
				}

				?>
			<?php } else {
				echo esc_html( $logo_text );
			} ?>
			<?php ?>
		</a>
		<a href="<?php echo esc_url( $this->get( 'home_url' ) ); ?>" class="go-to-site">
			<i class="fa fa-home"></i>
		</a>
	</div>
</nav>
