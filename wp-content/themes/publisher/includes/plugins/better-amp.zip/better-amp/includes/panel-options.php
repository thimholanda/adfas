<?php


// Admin panel options
add_filter( 'better-framework/panel/options', 'better_amp_option_panel' );


if ( ! function_exists( 'better_amp_option_panel' ) ) {

	/**
	 * Callback: Setup setting panel
	 *
	 * Filter: better-framework/panel/options
	 *
	 * @param $options
	 *
	 * @return array
	 */
	function better_amp_option_panel( $options ) {


		//
		//
		// Logo
		//
		//
		$fields[] = array(
			'name' => __( 'Logo', 'better-studio' ),
			'id'   => 'tab_amp_logo',
			'type' => 'tab',
			'icon' => 'bsai-header',
		);

		$fields['logo_image']      = array(
			'name'         => __( 'AMP Logo', 'better-studio' ),
			'id'           => 'logo_image',
			'desc'         => __( 'Upload your custom logo for AMP version of your site. <code>Note:</code> Read <a target="_blank" href="http://goo.gl/st7x4z">AMP Logo Guidelines</a> for more information.', 'better-studio' ),
			'std'          => '',
			'type'         => 'media_image',
			'media_title'  => __( 'Select or Upload Logo', 'better-studio' ),
			'media_button' => __( 'Select Image', 'better-studio' ),
			'upload_label' => __( 'Upload Logo', 'better-studio' ),
			'remove_label' => __( 'Remove', 'better-studio' ),
		);
		$fields['logo_image_size'] = array(
			'name'           => __( 'AMP Logo Size', 'better-studio' ),
			'id'             => 'logo_image_size',
			'desc'           => __( 'You should define the height and width of your AMP logo.', 'better-studio' ),
			'std'            => array(
				'width'  => '',
				'height' => '',
			),
			'type'           => 'custom',
			'input_callback' => '_better_amp_logo_size_field_code_callback'
		);


		//
		//
		// Footer
		//
		//
		$fields[] = array(
			'name' => __( 'footer', 'better-studio' ),
			'id'   => 'tab_amp_footer',
			'type' => 'tab',
			'icon' => 'bsai-footer',
		);
		$fields['footer_copy_1']       = array(
			'name' => __( 'Footer Copyright Text', 'better-studio' ),
			'desc' => __( 'Enter the copy right text of footer.<br>
You can use following pattern to make replace them with real data:<br><br>
<strong>%%year%%</strong>: Will replcae with current year, ex: 2015<br>
<strong>%%date%%</strong>: Will replcae with current year, ex: 2015<br>
<strong>%%sitename%%</strong>: Will replace with site title.<br>
<strong>%%title%%</strong>: Will replace with site title.<br>
<strong>%%siteurl%%</strong>: Will replace with site homepage url.', 'better-studio' ),
			'id'   => 'footer_copy_1',
			'std'  => '© %%year%% - %%sitename%%. All Rights Reserved.',
			'type' => 'textarea',
		);

		$fields[]                     = array(
			'name'  => __( 'Footer Logo', 'better-studio' ),
			'type'  => 'group',
			'state' => 'open',
		);
		$fields['footer_logo_image']      = array(
			'name'         => __( 'Footer Logo', 'better-studio' ),
			'id'           => 'footer_logo_image',
			'desc'         => __( 'Upload your custom logo for footer.', 'better-studio' ),
			'std'          => '',
			'type'         => 'media_image',
			'media_title'  => __( 'Select or Upload Logo', 'better-studio' ),
			'media_button' => __( 'Select Image', 'better-studio' ),
			'upload_label' => __( 'Upload Logo', 'better-studio' ),
			'remove_label' => __( 'Remove', 'better-studio' ),
		);
		$fields['footer_logo_image_size'] = array(
			'name'           => __( 'Footer Logo Size', 'better-studio' ),
			'id'             => 'footer_logo_image_size',
			'desc'           => __( 'You should define the height and width of your AMP logo.', 'better-studio' ),
			'std'            => array(
				'width'  => '',
				'height' => '',
			),
			'type'           => 'custom',
			'input_callback' => '_better_amp_footer_logo_size_field_code_callback'
		);

		
		/**
		 * => Import & Export
		 */
		bf_inject_panel_import_export_fields( $fields, array(
			'panel-id'         => Better_AMP::$panel_id,
			'export-file-name' => 'better-amp-options-backup',
		) );


		// Language  name for smart admin texts
		$lang = bf_get_current_lang_raw();
		if ( $lang != 'none' ) {
			$lang = bf_get_language_name( $lang );
		} else {
			$lang = '';
		}


		$options[ Better_AMP::$panel_id ] = array(
			'config'     => array(
				'parent'              => 'better-studio',
				'slug'                => 'better-studio/AMP',
				'name'                => __( 'Better AMP', 'better-studio' ),
				'page_title'          => __( 'Better AMP', 'better-studio' ),
				'menu_title'          => 'Better AMP',
				'capability'          => 'manage_options',
				'menu_slug'           => __( 'Better AMP', 'better-studio' ),
				'icon_url'            => NULL,
				'position'            => 80.02,
				'exclude_from_export' => FALSE,
			),
			'texts'      => array(
				'panel-desc-lang'     => '<p>' . __( '%s Language Options.', 'better-studio' ) . '</p>',
				'panel-desc-lang-all' => '<p>' . __( 'All Languages Options.', 'better-studio' ) . '</p>',
				'reset-button'        => ! empty( $lang ) ? sprintf( __( 'Reset %s Options', 'better-studio' ), $lang ) : __( 'Reset Options', 'better-studio' ),
				'reset-button-all'    => __( 'Reset All Options', 'better-studio' ),
				'reset-confirm'       => ! empty( $lang ) ? sprintf( __( 'Are you sure to reset %s options?', 'better-studio' ), $lang ) : __( 'Are you sure to reset options?', 'better-studio' ),
				'reset-confirm-all'   => __( 'Are you sure to reset all options?', 'better-studio' ),
				'save-button'         => ! empty( $lang ) ? sprintf( __( 'Save %s Options', 'better-studio' ), $lang ) : __( 'Save Options', 'better-studio' ),
				'save-button-all'     => __( 'Save All Options', 'better-studio' ),
				'save-confirm-all'    => __( 'Are you sure to save all options? this will override specified options per languages', 'better-studio' )
			),
			'panel-name' => _x( 'Better AMP', 'Panel title', 'better-studio' ),
			'panel-desc' => '<p>' . __( 'Custom configuration for Accelerated Mobile Pages Project', 'better-studio' ) . '</p>',
			'fields'     => $fields
		);

		return $options;
	}

}
