<?php

if( ! function_exists( '_better_amp_logo_size_field_code_callback' ) ){
	/**
	 * AMP Logo size field custom code
	 */
	function _better_amp_logo_size_field_code_callback(){

		$value = Better_AMP::get_option( 'logo_image_size' );

		if( ! isset( $value['height'] ) )
			$value['height'] = '';

		if( ! isset( $value['width'] ) )
			$value['width'] = '';

		?>
		<div class="bf-field-with-prefix" style="margin-bottom: 20px;">
			<span style="width: 50px;" class='bf-prefix'><?php _e( 'Width:', 'better-studio' ); ?></span>
			<input type="text" name="logo_image_size[width]" value="<?php echo $value['width']; ?>" >
		</div>

		<div class="bf-field-with-prefix" style="">
			<span style="width: 50px;" class='bf-prefix'><?php _e( 'Height:', 'better-studio' ); ?></span>
			<input type="text" name="logo_image_size[height]" value="<?php echo $value['height']; ?>" >
		</div>

		<script>
			jQuery(function($) {

				/*
				 todo make this more smart with warning user for images that have height more than 60px and 600px width
				*/
				$('#bf-panel.panel-better_amp .bf-media-image-upload-btn').bind( 'bf-media-image-changed:logo_image', function ( e, data ) {
					$('input[name="logo_image_size[height]"]').val( data.attachment.height );
					$('input[name="logo_image_size[width]"]').val( data.attachment.width );
				});

			});
		</script>
		<?php

	}
}

if( ! function_exists( '_better_amp_footer_logo_size_field_code_callback' ) ){
	/**
	 * AMP Logo size field custom code
	 */
	function _better_amp_footer_logo_size_field_code_callback(){

		$value = Better_AMP::get_option( 'footer_logo_image_size' );

		if( ! isset( $value['height'] ) )
			$value['height'] = '';

		if( ! isset( $value['width'] ) )
			$value['width'] = '';

		?>
		<div class="bf-field-with-prefix" style="margin-bottom: 20px;">
			<span style="width: 50px;" class='bf-prefix'><?php _e( 'Width:', 'better-studio' ); ?></span>
			<input type="text" name="footer_logo_image_size[width]" value="<?php echo $value['width']; ?>" >
		</div>

		<div class="bf-field-with-prefix" style="">
			<span style="width: 50px;" class='bf-prefix'><?php _e( 'Height:', 'better-studio' ); ?></span>
			<input type="text" name="footer_logo_image_size[height]" value="<?php echo $value['height']; ?>" >
		</div>

		<script>
			jQuery(function($) {

				/*
				 todo make this more smart with warning user for images that have height more than 60px and 600px width
				*/
				$('#bf-panel.panel-better_amp .bf-media-image-upload-btn').bind( 'bf-media-image-changed:footer_logo_image', function ( e, data ) {
					$('input[name="footer_logo_image_size[height]"]').val( data.attachment.height );
					$('input[name="footer_logo_image_size[width]"]').val( data.attachment.width );
				});

			});
		</script>
		<?php

	}
}
