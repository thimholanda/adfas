<?php

if ( ! class_exists( "WPBakeryShortCode" ) ) {
	class WPBakeryShortCode {

	}
}

/**
 * Wrapper for WPBakeryShortCode Class for handling editor
 */
class BF_VC_Shortcode_Extender extends WPBakeryShortCode {

}