<li class="amp-wp-posted-on">
	<time datetime="<?php echo esc_attr( date( 'c', $this->get( 'post_publish_timestamp' ) ) ); ?>">
		<?php echo publisher_get_readable_date( $this->get( 'post_publish_timestamp' ) ); ?>
	</time>
</li>
