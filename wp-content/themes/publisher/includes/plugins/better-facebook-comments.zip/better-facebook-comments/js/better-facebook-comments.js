var Better_Facebook_Comments = (function($) {
    "use strict";
    return {
        init: function(){

            Better_Facebook_Comments.links = [];

            // Collect all links for reliving count of them
            $('a[href$=#facebook_thread]').each( function( i ){
                Better_Facebook_Comments.links.push( $(this).attr('href') );
            });

            if( Better_Facebook_Comments.links.length > 0 ){
                this.get_count( Better_Facebook_Comments.links[0] );
            }

        },

        get_count: function( url ){
            $.ajax({
                type: 'GET',
                timeout: 2500,
                url: 'https://graph.facebook.com/v2.1/?fields=share{comment_count}&id=' + url,
                success: function( data ){

                    // Update count on age
                    var count = 0;
                    if( typeof data.share == "undefined" ||
                        typeof data.share.comment_count == "undefined"){
                        count = 0;
                    }else{
                        count = data.share.comment_count;
                    }

                    Better_Facebook_Comments.update_link( Better_Facebook_Comments.links[0], count );

                    // remove top element
                    Better_Facebook_Comments.links.shift();

                    // do next
                    if( Better_Facebook_Comments.links.length > 0 ) {
                        Better_Facebook_Comments.get_count(Better_Facebook_Comments.links[0]);
                    }
                },
                error: function( i, b) {

                    console.log( Better_Facebook_Comments.links[0] + ' -> ' + b );

                    Better_Facebook_Comments.update_link( Better_Facebook_Comments.links[0], 0 );

                    Better_Facebook_Comments.links.shift();

                    if( Better_Facebook_Comments.links.length > 0 ) {
                        Better_Facebook_Comments.get_count(Better_Facebook_Comments.links[0]);
                    }
                }
            });

        },

        update_link: function( url, count ){

            // Create template
            switch( count ){

                case 0:
                    count =  better_facebook_comments_vars.text_0.replace( "%%NUMBER%%", count);
                    break;

                case 1:
                    count =  better_facebook_comments_vars.text_1.replace( "%%NUMBER%%", count);
                    break;

                case 2:
                    count =  better_facebook_comments_vars.text_2.replace( "%%NUMBER%%", count);
                    break;

                default:
                    count =  better_facebook_comments_vars.text_more.replace( "%%NUMBER%%", count);
                    break;
            }

            // Add comment count to page
            $('a[href=\'' + url + '\']').each( function( i ){
                 $(this).html( count );
            });

        }

    };

})(jQuery);

// Load when ready
jQuery(function($) {

    //Better_Facebook_Comments.init();

});