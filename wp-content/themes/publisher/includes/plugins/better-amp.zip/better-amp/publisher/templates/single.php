<?php

$post_id = $this->get( 'post_id' );

$post_format = get_post_format( $post_id );

// set media url for video and audio formats
if ( in_array( $post_format, array( 'audio', 'video' ) ) ) {
	$media_url = bf_get_post_meta( '_featured_embed_code' );
} else {
	$media_url = '';
}

if ( ! empty( $media_url ) ) {

	$media = new AMP_Content( $media_url,
		apply_filters( 'amp_content_embed_handlers', array(
			'AMP_Twitter_Embed_Handler'   => array(),
			'AMP_YouTube_Embed_Handler'   => array(),
			'AMP_Instagram_Embed_Handler' => array(),
			'AMP_Vine_Embed_Handler'      => array(),
			'AMP_Facebook_Embed_Handler'  => array(),
			'AMP_Gallery_Embed_Handler'   => array(),
		), $this->post ),
		apply_filters( 'amp_content_sanitizers', array(
			'AMP_Blacklist_Sanitizer' => array(),
			'AMP_Img_Sanitizer'       => array(),
			'AMP_Video_Sanitizer'     => array(),
			'AMP_Audio_Sanitizer'     => array(),
			'AMP_Iframe_Sanitizer'    => array(
				'add_placeholder' => TRUE,
			),
		), $this->post ),
		array(
			'content_max_width' => $this->get( 'content_max_width' ),
		)
	);

}


?><!doctype html>
<html amp>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
	<?php do_action( 'amp_post_template_head', $this ); ?>

	<style amp-custom>
		<?php $this->load_parts( array( 'style' ) ); ?>
		<?php do_action( 'amp_post_template_css', $this ); ?>
	</style>
	<?php

	// Initialize custom css generator
	Better_Framework()->factory( 'custom-css' );
	$css_generator = new BF_Custom_CSS();

	// Collect fonts data
	$fonts['content']    = publisher_get_option( 'typo_entry_content' );
	$fonts['post_title'] = publisher_get_option( 'typo_post_heading' );
	$fonts['heading']    = publisher_get_option( 'typo_heading' );

	// inject fonts data to generator
	foreach ( $fonts as $_font ) {
		$css_generator->set_fonts( $_font['family'], $_font['variant'], $_font['subset'] );
	}

	// Print resource links for fonts
	foreach ( (array) $css_generator->render_fonts( 'google-fonts', 'https' ) as $_font ) {
		?>
		<link rel="stylesheet" href="<?php echo $_font; ?>">
		<?php
	}


	// Print needle custom scripts
	if ( ! empty( $media_url ) && $media->get_amp_scripts() ) {
		foreach ( (array) $media->get_amp_scripts() as $_script_id => $_script ) {
			?>
			<script async custom-element="<?php echo $_script_id; ?>" src="<?php echo $_script; ?>"></script>
			<?php
		}
	}

	?>
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<div class="amp-wp-content">
	<?php $this->load_parts( array( 'header-bar' ) ); ?>
	<h1 class="amp-wp-title"><span><?php echo wp_kses_data( $this->get( 'post_title' ) ); ?></span></h1>
	<ul class="amp-wp-meta">
		<?php $this->load_parts( apply_filters( 'amp_post_template_meta_parts', array(
			'meta-author',
			'meta-time',
			'meta-taxonomy'
		) ) ); ?>
	</ul>
	<div class="entry-content">
		<?php

		// Print post media
		if ( ! empty( $media_url ) ) {
			echo $media->get_amp_content();
		}elseif( has_post_thumbnail() ){
			echo '<p class="xyz-featured-image">', get_the_post_thumbnail() , '</p>';
		}

		echo $this->get( 'post_amp_content' ); // amphtml content; no kses

		?>
	</div>
	<?php $this->load_parts( array( 'footer-bar' ) ); ?>
</div>
<?php do_action( 'amp_post_template_footer', $this ); ?>
</body>
</html>
