<?php $categories = get_the_category_list( ', ' ); ?>
<?php if ( $categories ) : ?>
	<li class="amp-wp-tax-category">
		<span class="screen-reader-text"><?php publisher_translation()->_echo( 'categories' ); ?>:</span>
		<?php echo $categories; ?>
	</li>
<?php endif; ?>

<?php $tags = get_the_tag_list( '', ', ' ); ?>
<?php if ( $tags ) : ?>
	<li class="amp-wp-tax-tag">
		<span class="screen-reader-text"><?php publisher_translation()->_echo( 'tags' ); ?>:</span>
		<?php echo $tags; ?>
	</li>
<?php endif; ?>
