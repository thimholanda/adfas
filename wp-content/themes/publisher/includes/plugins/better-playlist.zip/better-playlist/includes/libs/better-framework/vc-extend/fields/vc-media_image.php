<?php

include BF_PATH . 'core/field-generator/fields/media_image.php';