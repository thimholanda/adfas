<?php

$highlight_color = publisher_get_option( 'theme_color' );

$fonts['content'] = publisher_get_option( 'typo_entry_content' );
$fonts['heading'] = publisher_get_option( 'typo_post_heading' );

?>
/* Generic WP styling */
.amp-wp-enforced-sizes {
	max-width: 100%;
}
.amp-wp-unknown-size img {
	object-fit: contain;
}

/* Template Styles */
.amp-wp-content,
.amp-wp-title-bar div {
	max-width: 743.333px;
	margin: 0 auto;
}

body {
	font-family: <?php echo $fonts['content']['family']; ?>, sans-serif;
	font-size:  <?php echo $fonts['content']['size']; ?>px;
	line-height: 1.8;
	background: #ececec;
	color: #333;
}

.amp-wp-content {
	padding: 0 25px;
	overflow-wrap: break-word;
	word-wrap: break-word;
	font-weight: 400;
	color: #333;
	background: #fff;
	box-shadow: 0 0 3px rgba(0, 0, 0, 0.06);
}
.amp-wp-title {
	font-family: <?php echo $fonts['heading']['family']; ?>, sans-serif;
	margin: 20px 0 0 0;
	font-size: 1.8em;
	line-height: 1.258;
	font-weight: 700;
	color: #333;
}
.amp-wp-meta {
	margin-bottom: 16px;
}

p,
ol,
ul,
figure {
	margin: 0 0 24px 0;
}

a,
a:visited {
	color: <?php echo $highlight_color  ?>;
}

a:hover,
a:active,
a:focus {
	color: <?php echo $highlight_color  ?>;
	opacity: 0.7;
}


/* UI Fonts */
.amp-wp-meta,
nav.amp-wp-title-bar,
.wp-caption-text {
	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen-Sans", "Ubuntu", "Cantarell", "Helvetica Neue", sans-serif;
	font-size: 15px;
}


/* Meta */
ul.amp-wp-meta {
	padding: 24px 0 0 0;
	margin: 0 0 24px 0;
}

ul.amp-wp-meta li {
	list-style: none;
	display: inline-block;
	margin: 0;
	line-height: 24px;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	max-width: 300px;
}

ul.amp-wp-meta li:before {
	content: "\2022";
	margin: 0 8px;
}

ul.amp-wp-meta li:first-child:before {
	display: none;
}

.amp-wp-meta{
	color: #989898;
}
.amp-wp-meta a {
	color: <?php echo $highlight_color; ?>
}

.amp-wp-meta .screen-reader-text {
	clip: rect(1px, 1px, 1px, 1px);
	height: 1px;
	overflow: hidden;
	position: absolute;
	width: 1px;
}

.amp-wp-byline amp-img {
	border-radius: 50%;
	border: 0;
	background: #f3f6f8;
	position: relative;
	top: 6px;
	margin-right: 6px;
}


/* Titlebar */
nav.amp-wp-title-bar {
	background: <?php echo $highlight_color; ?>;
	padding: 4px 16px 8px;
	line-height: 40px;
}

nav.amp-wp-title-bar div {
	color: #fff;
}

nav.amp-wp-title-bar a {
	color: #fff;
	text-decoration: none;
}
nav.amp-wp-title-bar .amp-wp-site-icon {
	/** site icon is 32px **/
	float: left;
	margin: 11px 8px 0 0;
	border-radius: 50%;
}
nav.amp-wp-title-bar .amp-wp-site-logo {
	vertical-align: middle;
}
nav.amp-wp-title-bar .go-to-site{
	float: right;
	font-size: 18px;
}

/* Other Elements */
amp-carousel {
	background: #000;
}

amp-iframe,
amp-youtube,
amp-instagram,
amp-vine {
	background: #f3f6f8;
}

amp-carousel > amp-img > img {
	object-fit: contain;
}

.amp-wp-iframe-placeholder {
	background: #f3f6f8 url( <?php echo esc_url( $this->get( 'placeholder_image_url' ) ); ?> ) no-repeat center 40%;
	background-size: 48px 48px;
	min-height: 48px;
}

.entry-content amp-iframe,
.entry-content amp-youtube,
.entry-content amp-instagram,
.entry-content amp-vine {
	margin-bottom: 20px;
}

@media (max-width: 780px) {
	.amp-wp-title span{
		font-size: 83%;
	}

}
@media (max-width: 600px) {
	.entry-content .wp-caption.alignleft.alignleft,
	.entry-content .alignleft.alignleft {
		margin: 10px 0 15px 0;
		float: none;
	}
	.entry-content .wp-caption.alignright.alignright,
	.entry-content .alignright.alignright{
		margin: 10px 0 15px 0;
		float: none;
	}
	.entry-content .wp-caption.alignright.alignright .wp-caption-text,
	.entry-content figure.alignright.alignright .wp-caption-text{
		text-align:left;
	}
}

.amp-wp-footer{
	padding: 20px 25px;
	background: #ececec;
	text-align:center;
	margin-top: 50px;
}
.amp-wp-footer .footer-logo{
	margin: 15px 0px;
}
.footer-copyright p{
	font-size: 14px;
}
.footer-copyright p:last-child{
	margin-bottom: 0;
}

<?php

publisher_set_global( 'is-amp-css-request', true );

include PUBLISHER_THEME_PATH . 'includes/dynamics/global_content_css.php';

?>