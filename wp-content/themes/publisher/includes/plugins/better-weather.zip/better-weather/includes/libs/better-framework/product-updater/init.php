<?php

define( 'BS_PRODUCT_UPDATE_URI', trailingslashit( BF_URI . 'product-updater/' ) );
define( 'BS_PRODUCT_UPDATE_PATH', trailingslashit( BF_PATH . 'product-updater/' ) );

include_once BS_PRODUCT_UPDATE_PATH . 'class-bf-product-updater.php';
include_once BS_PRODUCT_UPDATE_PATH . 'functions.php';

