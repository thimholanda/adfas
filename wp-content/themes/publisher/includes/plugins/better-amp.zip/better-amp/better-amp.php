<?php
/*
Plugin Name: Better AMP ( Accelerated Mobile Pages )
Plugin URI: https://themeforest.net/user/better-studio/portfolio?ref=Better-Studio
Description: Enables your site to load 4x faster in everywhere!
Version: 1.1.3
Author: BetterStudio
Author URI: http://betterstudio.com
Text Domain: better-studio
*/

// Fire up BetterAMP
new Better_AMP();

class Better_AMP {

	/**
	 * Contains BAMP version number that used for assets for preventing cache mechanism
	 *
	 * @var string
	 */
	private static $version = '1.1.3';


	/**
	 * Contains plugin option panel ID
	 *
	 * @var string
	 */
	public static $panel_id = 'better_amp';


	function __construct() {

		// Register included BF
		add_filter( 'better-framework/loader', array( $this, 'better_framework_loader' ) );

		// Add handy functions
		include $this->dir_path( 'includes/functions.php' );

		// Init AMP for Publisher
		include $this->dir_path( 'publisher/init.php' );

		// Add option panel
		include $this->dir_path( 'includes/panel-options.php' );

		// load text domain
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		// init wp amp plugin
		add_action( 'plugins_loaded', array( $this, 'init_amp' ), 100 );

		// Includes BF loader if not included before
		require_once $this->dir_path( 'includes/libs/better-framework/init.php' );

		register_activation_hook( __FILE__, array( 'Better_AMP', 'plugin_activated' ) );
	}


	/**
	 * Fires when AMP activated
	 */
	function plugin_activated() {
		flush_rewrite_rules( TRUE );
	}


	/**
	 * Callback: Adds included BetterFramework to BF loader
	 *
	 * Filter: better-framework/loader
	 *
	 * @param $frameworks
	 *
	 * @return array
	 */
	function better_framework_loader( $frameworks ) {

		$frameworks[] = array(
			'version' => '2.6.2',
			'path'    => $this->dir_path( 'includes/libs/better-framework/' ),
			'uri'     => $this->dir_url( 'includes/libs/better-framework/' ),
		);

		return $frameworks;

	}


	/**
	 * Returns BPL current Version
	 *
	 * @return string
	 */
	static function get_version() {
		return self::$version;
	}


	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public static function get_option( $option_key ) {
		return bf_get_option( $option_key, self::$panel_id );
	}


	/**
	 * Load plugin textdomain.
	 *
	 * @since 1.0.0
	 */
	function load_textdomain() {
		// Register text domain
		load_plugin_textdomain( 'better-studio', FALSE, 'better-playlist/languages' );
	}


	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public static function dir_url( $address = '' ) {
		return plugin_dir_url( __FILE__ ) . ltrim( $address, '/' );
	}


	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public static function dir_path( $address = '' ) {
		return plugin_dir_path( __FILE__ ) . ltrim( $address, '/' );
	}


	/**
	 * Initialize base plugin for functionality
	 */
	public function init_amp() {

		if ( ! function_exists( 'amp_init' ) ) {
			require_once $this->dir_path( 'includes/libs/amp/amp.php' );
		}

	}

} // Better_AMP