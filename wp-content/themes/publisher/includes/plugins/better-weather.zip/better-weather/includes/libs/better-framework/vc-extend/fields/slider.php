<?php

include BF_PATH . 'core/field-generator/fields/slider.php';