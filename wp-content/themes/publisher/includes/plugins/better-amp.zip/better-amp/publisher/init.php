<?php

// Customize AMP plugin templates directory
add_filter( 'amp_post_template_dir', 'publisher_amp_post_template_dir', 100 );

if ( ! function_exists( 'publisher_amp_post_template_dir' ) ) {
	/**
	 * Callback: change AMP plugin template
	 * Filter: amp_post_template_dir
	 *
	 * @param $dir
	 *
	 * @return string
	 */
	function publisher_amp_post_template_dir( $dir ) {
		return Better_AMP::dir_path( 'publisher/templates' );
	}
}
